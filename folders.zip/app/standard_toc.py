STANDARD_TOC = [
    "1. Introduction",
    "1.1 Purpose",
    "1.2 Scope",
    "1.3 Definitions",
    "2. References",
    "3. System Overview",
    "4. System Features",
    "5. External Interface Requirements",
    "6. Other Requirements",
    "7. Appendices",
]
